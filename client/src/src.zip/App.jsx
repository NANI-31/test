import React from "react";
import Login from "./pages/LoginPage";
export default function App() {
  return (
    <div>
      <Login />
    </div>
  );
}
